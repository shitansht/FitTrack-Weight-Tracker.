
package com.fittrack.fittrack.resources;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        String sqlUsers = "SELECT COUNT(*) FROM users";
        String sqlWeights = "SELECT COUNT(*) FROM weight_logs";
        String sqlAverage =
                "SELECT AVG(weight) FROM weight_logs";
        String sqlTargets =
                "SELECT COUNT(*) FROM users u "
                + "WHERE EXISTS (SELECT 1 FROM weight_logs w "
                + "WHERE w.user_id = u.id) "
                + "AND (SELECT w.weight FROM weight_logs w "
                + "WHERE w.user_id = u.id "
                + "ORDER BY w.log_date DESC, w.id DESC LIMIT 1) "
                + "<= u.target_weight";

        try (Connection con = DBConnection.getConnection()) {

            request.setAttribute("totalUsers",
                    getCount(con, sqlUsers));

            request.setAttribute("totalWeights",
                    getCount(con, sqlWeights));

            try (PreparedStatement ps =
                    con.prepareStatement(sqlAverage);
                 ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    request.setAttribute(
                            "averageWeight", rs.getBigDecimal(1));
                }
            }

            request.setAttribute("targetsReached",
                    getCount(con, sqlTargets));

            request.getRequestDispatcher("/dashboard.jsp")
                    .forward(request, response);

        } catch (java.sql.SQLException e) {
            throw new ServletException(
                    "Unable to load FitTrack dashboard.", e);
        }
    }

    private int getCount(Connection con, String sql)
            throws java.sql.SQLException {

        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            rs.next();
            return rs.getInt(1);
        }
    }
}
