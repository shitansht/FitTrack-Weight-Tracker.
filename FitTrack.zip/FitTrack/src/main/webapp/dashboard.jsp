
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.math.BigDecimal" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FitTrack Dashboard</title>

    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            padding: 30px;
            background: #f1f5fb;
            color: #17202a;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 1200px;
            margin: auto;
        }

        h1 { color: #176c82; }

        nav {
            display: flex;
            flex-wrap: wrap;
            gap: 22px;
            padding: 16px 0;
            border-bottom: 1px solid #cbd5e1;
        }

        nav a {
            color: #176c82;
            font-weight: bold;
            text-decoration: none;
        }

        nav a:hover { text-decoration: underline; }

        .cards {
            display: grid;
            grid-template-columns: repeat(
                auto-fit, minmax(210px, 1fr));
            gap: 20px;
            margin-top: 25px;
        }

        .card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 3px 10px #00000012;
        }

        .number {
            font-size: 32px;
            font-weight: bold;
            color: #176c82;
        }

        .quick-links {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 25px;
        }

        .button {
            display: inline-block;
            padding: 13px 18px;
            border-radius: 7px;
            background: #176c82;
            color: white;
            text-decoration: none;
        }

        @media (max-width: 600px) {
            body { padding: 16px; }
        }
    </style>
</head>

<body>
<div class="container">

    <h1>FitTrack Dashboard</h1>
    <p>Monitor users, weight records and fitness progress.</p>

    <nav>
        <a href="dashboard">Dashboard</a>
        <a href="users.jsp">User Management</a>
        <a href="index.html">Register User</a>
        <a href="weight">Weight Tracking</a>
        <a href="reports.jsp">Progress Reports</a>
    </nav>

    <div class="cards">

        <div class="card">
            <h3>Total Registered Users</h3>
            <div class="number">
                <%= request.getAttribute("totalUsers") %>
            </div>
        </div>

        <div class="card">
            <h3>Weight Records</h3>
            <div class="number">
                <%= request.getAttribute("totalWeights") %>
            </div>
        </div>

        <div class="card">
            <h3>Average Recorded Weight</h3>
            <div class="number">
                <%
                    BigDecimal avg = (BigDecimal)
                        request.getAttribute("averageWeight");
                    out.print(avg == null ? "--"
                        : avg.setScale(2,
                            java.math.RoundingMode.HALF_UP) + " kg");
                %>
            </div>
        </div>

        <div class="card">
            <h3>Users Reaching Target</h3>
            <div class="number">
                <%= request.getAttribute("targetsReached") %>
            </div>
        </div>

    </div>

    <h2>Quick Actions</h2>

    <div class="quick-links">
        <a class="button" href="index.html">+ Register User</a>
        <a class="button" href="users.jsp">View All Users</a>
        <a class="button" href="weight">Add Weight Entry</a>
    </div>

</div>
</body>
</html>
