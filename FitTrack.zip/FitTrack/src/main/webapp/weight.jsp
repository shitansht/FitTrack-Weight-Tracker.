
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List,java.util.Map" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FitTrack - Weight Tracker</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            margin: 0;
            padding: 30px;
            font-family: Arial, sans-serif;
            background: #101820;
            color: white;
        }
        .container {
            max-width: 850px;
            margin: auto;
        }
        .card {
            background: #1b2838;
            padding: 24px;
            margin: 20px 0;
            border-radius: 12px;
        }
        input, button {
            padding: 12px;
            margin: 8px 0;
            border-radius: 6px;
            border: 1px solid #526477;
            box-sizing: border-box;
        }
        input {
            display: block;
            width: 100%;
            background: #fff;
            color: #111;
        }
        button {
            background: #38bdf8;
            color: #101820;
            font-weight: bold;
            cursor: pointer;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            border-bottom: 1px solid #526477;
            text-align: left;
        }
        .error { color: #ff8585; }
    </style>
</head>
<body>
<div class="container">
    <h1>FitTrack</h1>
    <p>Your personal weight tracking dashboard</p>

    <div class="card">
        <h2>Add Weight Entry</h2>

        <% if (request.getAttribute("error") != null) { %>
            <p class="error"><%= request.getAttribute("error") %></p>
        <% } %>

        <form action="<%= request.getContextPath() %>/weight"
              method="post">
            <label for="log_date">Date</label>
            <input type="date" id="log_date" name="log_date"
                   required>

            <label for="weight">Weight (kg)</label>
            <input type="number" id="weight" name="weight"
                   min="0.01" max="999.99" step="0.01"
                   placeholder="e.g. 74.50" required>

            <button type="submit">Save Weight</button>
        </form>
    </div>

    <div class="card">
        <h2>Weight History</h2>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Weight (kg)</th>
                </tr>
            </thead>
            <tbody>
            <%
                List<Map<String, Object>> logs =
                    (List<Map<String, Object>>) request.getAttribute("logs");

                if (logs != null && !logs.isEmpty()) {
                    for (Map<String, Object> log : logs) {
            %>
                <tr>
                    <td><%= log.get("log_date") %></td>
                    <td><%= log.get("weight") %></td>
                </tr>
            <%
                    }
                } else {
            %>
                <tr>
                    <td colspan="2">No weight records yet. Add your first entry.</td>
                </tr>
            <% } %>
            </tbody>
        </table>
    </div>
</div>
            <div class="card">
    <h2>Weight Progress</h2>
    <canvas id="weightChart" height="120"></canvas>
</div>
            
<script>
    const canvas = document.getElementById('weightChart');

    if (canvas && typeof Chart !== 'undefined') {
        new Chart(canvas, {
            type: 'line',
            data: {
                labels: [
                    <%
                    if (logs != null) {
                        for (Map<String, Object> log : logs) {
                    %>
                    '<%= log.get("log_date") %>',
                    <%
                        }
                    }
                    %>
                ],
                datasets: [{
                    label: 'Weight (kg)',
                    data: [
                        <%
                        if (logs != null) {
                            for (Map<String, Object> log : logs) {
                        %>
                        <%= log.get("weight") %>,
                        <%
                            }
                        }
                        %>
                    ],
                    borderColor: '#38bdf8',
                    backgroundColor: 'rgba(56, 189, 248, 0.2)',
                    borderWidth: 3,
                    pointRadius: 5,
                    tension: 0.3,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        labels: { color: '#ffffff' }
                    }
                },
                scales: {
                    x: {
                        ticks: { color: '#ffffff' }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Weight (kg)',
                            color: '#ffffff'
                        },
                        ticks: { color: '#ffffff' }
                    }
                }
            }
        });
    }
</script>

</body>
</html>
