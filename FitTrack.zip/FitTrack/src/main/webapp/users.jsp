
<%@ page import="java.sql.*" %>
<%@ page import="java.math.BigDecimal" %>
<%@ page import="java.math.RoundingMode" %>
<%@ page import="com.fittrack.fittrack.resources.DBConnection" %>

<%!
    // Escape database values before displaying them in HTML.
    private String escapeHtml(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FitTrack - User Management</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px;
            font-family: Arial, sans-serif;
            background: #101820;
            color: white;
        }

        .container {
            max-width: 1250px;
            margin: auto;
        }

        .muted {
            color: #cbd5e1;
        }

        .nav {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin: 25px 0;
        }

        a.button {
            color: #101820;
            background: #38bdf8;
            padding: 11px 15px;
            border-radius: 7px;
            text-decoration: none;
            display: inline-block;
            font-weight: bold;
            border: none;
            cursor: pointer;
        }

        a.button:hover {
            background: #7dd3fc;
        }

        .card {
            background: #1c2b3b;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 25px;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 14px;
            border-bottom: 1px solid #526273;
            text-align: left;
            white-space: nowrap;
        }

        th {
            color: #38bdf8;
        }

        .stats {
            display: grid;
            grid-template-columns:
                repeat(auto-fit, minmax(190px, 1fr));
            gap: 16px;
            margin: 25px 0;
        }

        .stat {
            background: #1c2b3b;
            padding: 22px;
            border-radius: 12px;
        }

        .stat h2 {
            color: #38bdf8;
            margin: 12px 0 0;
            overflow-wrap: anywhere;
        }

        .progress-good {
            color: #4ade80;
        }

        .progress-warning {
            color: #fbbf24;
        }

        .progress-neutral {
            color: #cbd5e1;
        }

        .error {
            color: #fca5a5;
        }

        @media (max-width: 600px) {
            body {
                padding: 15px;
            }

            .card {
                padding: 15px;
            }

            th, td {
                padding: 10px;
            }
        }
    </style>
</head>

<body>
<div class="container">

    <h1>FitTrack - User Management</h1>
    <p class="muted">
        Manage registered users and view individual fitness profiles.
    </p>

    <div class="nav">
        <a class="button" href="dashboard">Dashboard</a>
        <a class="button" href="index.html">Register User</a>
        <a class="button" href="weight.jsp">Weight Tracker</a>
    </div>

    <%
        int totalUsers = 0;
        int totalEntries = 0;
        int usersAtTarget = 0;
        int weightCount = 0;

        BigDecimal weightSum = BigDecimal.ZERO;
        String errorMessage = null;

        String sql =
            "SELECT u.id, u.name, u.email, u.target_weight, " +
            "(SELECT wl.weight FROM weight_logs wl " +
            " WHERE wl.user_id = u.id " +
            " ORDER BY wl.log_date DESC, wl.id DESC LIMIT 1) " +
            " AS latest_weight, " +
            "(SELECT COUNT(*) FROM weight_logs wl " +
            " WHERE wl.user_id = u.id) AS total_entries " +
            "FROM users u ORDER BY u.id DESC";
    %>

    <div class="stats">

        <div class="stat">
            <p>Total Registered Users</p>
            <h2><%= totalUsers %></h2>
        </div>

        <div class="stat">
            <p>Total Weight Entries</p>
            <h2 id="totalEntries">0</h2>
        </div>

        <div class="stat">
            <p>Average Latest Weight</p>
            <h2 id="averageWeight">No data</h2>
        </div>

        <div class="stat">
            <p>Users At Target</p>
            <h2 id="usersAtTarget">0</h2>
        </div>

    </div>

    <div class="card">
        <h2>Registered Users</h2>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Target (kg)</th>
                    <th>Latest Weight (kg)</th>
                    <th>Entries</th>
                    <th>Progress</th>
                    <th>Profile</th>
                </tr>
            </thead>

            <tbody>
            <%
                try (
                    Connection con = DBConnection.getConnection();
                    PreparedStatement ps = con.prepareStatement(sql);
                    ResultSet rs = ps.executeQuery()
                ) {
                    while (rs.next()) {
                        totalUsers++;

                        int id = rs.getInt("id");
                        String name = rs.getString("name");
                        String email = rs.getString("email");

                        BigDecimal target =
                            rs.getBigDecimal("target_weight");

                        BigDecimal latest =
                            rs.getBigDecimal("latest_weight");

                        int entries = rs.getInt("total_entries");

                        totalEntries += entries;

                        if (latest != null) {
                            weightSum = weightSum.add(latest);
                            weightCount++;
                        }

                        String progress = "Add weight data";
                        String progressClass = "progress-neutral";

                        if (target != null && latest != null) {
                            int comparison = latest.compareTo(target);

                            if (comparison == 0) {
                                progress = "Target reached";
                                progressClass = "progress-good";
                                usersAtTarget++;
                            } else if (comparison > 0) {
                                progress = latest.subtract(target)
                                    .setScale(2, RoundingMode.HALF_UP)
                                    .toPlainString() + " kg above target";

                                progressClass = "progress-warning";
                            } else {
                                progress = target.subtract(latest)
                                    .setScale(2, RoundingMode.HALF_UP)
                                    .toPlainString() + " kg below target";

                                progressClass = "progress-good";
                            }
                        }
            %>

                <tr>
                    <td><%= id %></td>

                    <td><%= escapeHtml(name) %></td>

                    <td><%= escapeHtml(email) %></td>

                    <td>
                        <%= target == null
                            ? "Not set"
                            : target.toPlainString() %>
                    </td>

                    <td>
                        <%= latest == null
                            ? "No entries"
                            : latest.toPlainString() %>
                    </td>

                    <td><%= entries %></td>

                    <td class="<%= progressClass %>">
                        <%= escapeHtml(progress) %>
                    </td>

                    <td>
                        <a class="button"
                           href="profile.jsp?id=<%= id %>">
                            View Profile
                        </a>
                    </td>
                </tr>

            <%
                    }

                    if (totalUsers == 0) {
            %>

                <tr>
                    <td colspan="8">
                        No registered users yet.
                    </td>
                </tr>

            <%
                    }
                } catch (SQLException e) {
                    application.log("Unable to load users", e);
                    errorMessage =
                        "Unable to load users. Check the server log.";
                }

                String averageWeight = "No data";

                if (weightCount > 0) {
                    averageWeight = weightSum
                        .divide(
                            BigDecimal.valueOf(weightCount),
                            2,
                            RoundingMode.HALF_UP
                        )
                        .toPlainString() + " kg";
                }
            %>
            </tbody>
        </table>

        <% if (errorMessage != null) { %>
            <p class="error"><%= errorMessage %></p>
        <% } %>
    </div>

    <script>
        document.querySelector(".stats .stat:nth-child(1) h2")
            .textContent = "<%= totalUsers %>";

        document.getElementById("totalEntries").textContent =
            "<%= totalEntries %>";

        document.getElementById("averageWeight").textContent =
            "<%= averageWeight %>";

        document.getElementById("usersAtTarget").textContent =
            "<%= usersAtTarget %>";
    </script>

</div>
</body>
</html>
