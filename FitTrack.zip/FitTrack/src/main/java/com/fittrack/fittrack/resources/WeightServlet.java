
package com.fittrack.fittrack.resources;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/weight")
public class WeightServlet extends HttpServlet {

    private static final int USER_ID = 1;

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        List<Map<String, Object>> logs = new ArrayList<>();

        String sql = "SELECT id, log_date, weight "
                   + "FROM weight_logs "
                   + "WHERE user_id = ? "
                   + "ORDER BY log_date DESC, id DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, USER_ID);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> log = new HashMap<>();
                    log.put("id", rs.getInt("id"));
                    log.put("log_date", rs.getDate("log_date"));
                    log.put("weight", rs.getBigDecimal("weight"));
                    logs.add(log);
                }
            }

            request.setAttribute("logs", logs);

        } catch (SQLException e) {
            getServletContext().log("Unable to load weight records", e);
            request.setAttribute(
                "error", "Could not load weight records. Check MySQL."
            );
        }

        request.getRequestDispatcher("/weight.jsp")
               .forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        try {
            String dateText = request.getParameter("log_date");
            String weightText = request.getParameter("weight");

            if (dateText == null || dateText.trim().isEmpty()
                    || weightText == null || weightText.trim().isEmpty()) {
                throw new IllegalArgumentException(
                    "Enter both date and weight."
                );
            }

            Date logDate = Date.valueOf(dateText.trim());
            BigDecimal weight = new BigDecimal(weightText.trim());

            if (weight.compareTo(BigDecimal.ZERO) <= 0
                    || weight.compareTo(new BigDecimal("999.99")) > 0) {
                throw new IllegalArgumentException(
                    "Weight must be between 0 and 999.99 kg."
                );
            }

            String sql = "INSERT INTO weight_logs "
                       + "(user_id, log_date, weight) VALUES (?, ?, ?)";

            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, USER_ID);
                ps.setDate(2, logDate);
                ps.setBigDecimal(3, weight);
                ps.executeUpdate();
            }

            response.sendRedirect(request.getContextPath() + "/weight");

        } catch (IllegalArgumentException e) {
            response.sendError(
                HttpServletResponse.SC_BAD_REQUEST, e.getMessage()
            );
        } catch (SQLException e) {
            getServletContext().log("Unable to save weight record", e);
            response.sendError(
                HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                "Could not save weight. Check the server log."
            );
        }
    }
}
