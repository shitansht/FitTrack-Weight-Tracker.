
<%@ page import="java.sql.*" %>
<%@ page import="java.math.BigDecimal" %>
<%@ page import="java.math.RoundingMode" %>
<%@ page import="java.util.*" %>
<%@ page import="com.fittrack.fittrack.resources.DBConnection" %>

<%!
    private String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
%>

<%
    request.setCharacterEncoding("UTF-8");

    int userId = 0;
    boolean validId = false;

    try {
        userId = Integer.parseInt(request.getParameter("id"));
        validId = userId > 0;
    } catch (Exception ignored) {
        validId = false;
    }

    String name = "";
    String email = "";
    BigDecimal target = null;
    BigDecimal latest = null;
    BigDecimal firstWeight = null;
    BigDecimal totalChange = null;
    int totalEntries = 0;

    boolean userFound = false;
    String errorMessage = null;

    List<String> dates = new ArrayList<>();
    List<Double> weights = new ArrayList<>();

    if (validId) {
        String userSql =
            "SELECT id, name, email, target_weight " +
            "FROM users WHERE id = ?";

        String weightSql =
            "SELECT id, weight, log_date FROM weight_logs " +
            "WHERE user_id = ? " +
            "ORDER BY log_date ASC, id ASC";

        try (Connection con = DBConnection.getConnection()) {

            try (PreparedStatement ps = con.prepareStatement(userSql)) {
                ps.setInt(1, userId);

                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        userFound = true;
                        name = rs.getString("name");
                        email = rs.getString("email");
                        target = rs.getBigDecimal("target_weight");
                    }
                }
            }

            if (userFound) {
                try (PreparedStatement ps =
                         con.prepareStatement(weightSql)) {

                    ps.setInt(1, userId);

                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            BigDecimal weight =
                                rs.getBigDecimal("weight");

                            java.sql.Date date =
                                rs.getDate("log_date");

                            dates.add(date == null
                                ? ""
                                : date.toString());

                            weights.add(weight.doubleValue());
                            totalEntries++;

                            if (firstWeight == null) {
                                firstWeight = weight;
                            }

                            latest = weight;
                        }
                    }
                }

                if (firstWeight != null && latest != null) {
                    totalChange = latest.subtract(firstWeight);
                }
            }

        } catch (SQLException e) {
            application.log("Unable to load user profile", e);
            errorMessage =
                "Unable to load this profile. Check the server log.";
        }
    }

    String progressText = "No weight data yet";
    String progressClass = "neutral";

    if (latest != null && target != null) {
        int comparison = latest.compareTo(target);

        if (comparison == 0) {
            progressText = "Target reached!";
            progressClass = "good";
        } else if (comparison > 0) {
            progressText = latest.subtract(target)
                .setScale(2, RoundingMode.HALF_UP)
                .toPlainString() + " kg above target";
            progressClass = "warning";
        } else {
            progressText = target.subtract(latest)
                .setScale(2, RoundingMode.HALF_UP)
                .toPlainString() + " kg below target";
            progressClass = "good";
        }
    }

    String chartLabels = dates.toString();
    String chartWeights = weights.toString();
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FitTrack - User Profile</title>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            padding: 30px;
            font-family: Arial, sans-serif;
            background: #101820;
            color: white;
        }

        .container {
            max-width: 1150px;
            margin: auto;
        }

        .muted { color: #cbd5e1; }

        .nav {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin: 25px 0;
        }

        .button {
            display: inline-block;
            padding: 11px 15px;
            border-radius: 7px;
            background: #38bdf8;
            color: #101820;
            text-decoration: none;
            font-weight: bold;
        }

        .card {
            background: #1c2b3b;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 22px;
            overflow-x: auto;
        }

        .grid {
            display: grid;
            grid-template-columns:
                repeat(auto-fit, minmax(210px, 1fr));
            gap: 16px;
        }

        .stat {
            background: #24384b;
            padding: 20px;
            border-radius: 10px;
        }

        .stat h2 {
    color: #38bdf8;
    margin-bottom: 0;
    font-size: 23px;
    line-height: 1.4;
    overflow-wrap: anywhere;
    word-break: normal;
}

.card + .grid {
    margin-top: 24px;
}

.grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}

.stat {
    background: #24384b;
    padding: 20px;
    border-radius: 10px;
    min-width: 0;

        }

        .good { color: #4ade80; }
        .warning { color: #fbbf24; }
        .neutral { color: #cbd5e1; }
        .error { color: #fca5a5; }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            text-align: left;
            padding: 13px;
            border-bottom: 1px solid #526273;
            white-space: nowrap;
        }

        th { color: #38bdf8; }

        .chart-wrap {
            position: relative;
            height: 330px;
            width: 100%;
        }

        @media (max-width: 600px) {
            body { padding: 15px; }
            .card { padding: 16px; }
        }
    </style>
</head>

<body>
<div class="container">

    <h1>FitTrack - Individual Profile</h1>
    <p class="muted">
        Personal details, weight history and fitness progress.
    </p>

    <div class="nav">
        <a class="button" href="dashboard">Dashboard</a>
        <a class="button" href="users.jsp">All Users</a>
        <a class="button" href="index.html">Register User</a>
        <a class="button" href="weight.jsp">Weight Tracker</a>
    </div>

    <% if (!validId) { %>

        <div class="card">
            <h2>Invalid user ID</h2>
            <p>Please open a profile from the User Management page.</p>
        </div>

    <% } else if (errorMessage != null) { %>

        <div class="card">
            <p class="error"><%= esc(errorMessage) %></p>
        </div>

    <% } else if (!userFound) { %>

        <div class="card">
            <h2>User not found</h2>
            <p>No registered user exists with ID <%= userId %>.</p>
        </div>

    <% } else { %>

        <div class="card">
            <h2>Personal Details</h2>

            <div class="grid">
                <div class="stat">
                    <p>User ID</p>
                    <h2><%= userId %></h2>
                </div>

                <div class="stat">
                    <p>Full Name</p>
                    <h2><%= esc(name) %></h2>
                </div>

                <div class="stat">
                    <p>Email Address</p>
                    <h2><%= esc(email) %></h2>
                </div>

                <div class="stat">
                    <p>Target Weight</p>
                    <h2>
                        <%= target == null
                            ? "Not set"
                            : target.toPlainString() + " kg" %>
                    </h2>
                </div>
            </div>
        </div>

        <div class="grid">

            <div class="stat">
                <p>Latest Weight</p>
                <h2>
                    <%= latest == null
                        ? "No data"
                        : latest.toPlainString() + " kg" %>
                </h2>
            </div>

            <div class="stat">
                <p>Total Weight Entries</p>
                <h2><%= totalEntries %></h2>
            </div>

            <div class="stat">
                <p>Change Since First Entry</p>
                <h2>
                    <% if (totalChange == null) { %>
                        No data
                    <% } else { %>
                        <%= totalChange.compareTo(BigDecimal.ZERO) > 0
                            ? "+" : "" %><%= totalChange.toPlainString() %> kg
                    <% } %>
                </h2>
            </div>

            <div class="stat">
                <p>Target Progress</p>
                <h2 class="<%= progressClass %>">
                    <%= esc(progressText) %>
                </h2>
            </div>

        </div>

        <div class="card">
            <h2>Weight Progress Chart</h2>

            <% if (totalEntries == 0) { %>
                <p class="muted">
                    No weight records yet. Add an entry to see your chart.
                </p>
            <% } else { %>
                <div class="chart-wrap">
                    <canvas id="weightChart"></canvas>
                </div>
            <% } %>
        </div>

        <div class="card">
            <h2>Complete Weight History</h2>

            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Date</th>
                        <th>Weight (kg)</th>
                    </tr>
                </thead>

                <tbody>
                    <% if (totalEntries == 0) { %>
                        <tr>
                            <td colspan="3">
                                No weight records for this user.
                            </td>
                        </tr>
                    <% } else {
                        for (int i = totalEntries - 1; i >= 0; i--) {
                    %>
                        <tr>
                            <td><%= totalEntries - i %></td>
                            <td><%= esc(dates.get(i)) %></td>
                            <td>
                                <%= BigDecimal.valueOf(weights.get(i))
                                    .setScale(2, RoundingMode.HALF_UP)
                                    .toPlainString() %>
                            </td>
                        </tr>
                    <%  }
                    } %>
                </tbody>
            </table>
        </div>

        <script>
            const labels = <%= chartLabels %>;
            const weightData = <%= chartWeights %>;

            const canvas = document.getElementById("weightChart");

            if (canvas) {
                new Chart(canvas, {
                    type: "line",
                    data: {
                        labels: labels,
                        datasets: [{
                            label: "Weight (kg)",
                            data: weightData,
                            borderColor: "#38bdf8",
                            backgroundColor: "rgba(56,189,248,0.15)",
                            borderWidth: 3,
                            pointRadius: 5,
                            pointBackgroundColor: "#38bdf8",
                            fill: true,
                            tension: 0.25
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                labels: { color: "#ffffff" }
                            }
                        },
                        scales: {
                            x: {
                                ticks: { color: "#cbd5e1" },
                                grid: {
                                    color: "rgba(203,213,225,0.1)"
                                }
                            },
                            y: {
                                beginAtZero: false,
                                ticks: { color: "#cbd5e1" },
                                grid: {
                                    color: "rgba(203,213,225,0.1)"
                                },
                                title: {
                                    display: true,
                                    text: "Weight (kg)",
                                    color: "#ffffff"
                                }
                            }
                        }
                    }
                });
            }
        </script>

    <% } %>

</div>
</body>
</html>
