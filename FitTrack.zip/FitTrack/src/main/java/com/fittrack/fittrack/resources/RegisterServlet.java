
package com.fittrack.fittrack.resources;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String targetText = request.getParameter("target_weight");

        if (name == null || name.trim().isEmpty()
                || email == null || email.trim().isEmpty()
                || targetText == null || targetText.trim().isEmpty()) {
            response.sendError(400, "Please fill in all required fields.");
            return;
        }

        try {
            java.math.BigDecimal target =
                    new java.math.BigDecimal(targetText.trim());

            if (target.compareTo(java.math.BigDecimal.ZERO) <= 0
                    || target.compareTo(
                    new java.math.BigDecimal("999.99")) > 0) {
                response.sendError(400, "Enter a valid target weight.");
                return;
            }

            String sql = "INSERT INTO users "
                    + "(name, email, target_weight) VALUES (?, ?, ?)";

            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, name.trim());
                ps.setString(2, email.trim());
                ps.setBigDecimal(3, target);
                ps.executeUpdate();
            }

            response.sendRedirect(
                    request.getContextPath() + "/index.html?registered=1");

        } catch (NumberFormatException e) {
            response.sendError(400, "Target weight must be a number.");
        } catch (SQLException e) {
            if ("23000".equals(e.getSQLState())) {
                response.sendError(409, "This email may already be registered.");
            } else {
                throw new ServletException("Registration failed.", e);
            }
        }
    }
}
